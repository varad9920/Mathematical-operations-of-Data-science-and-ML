#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import datetime as dt

import matplotlib.pyplot as plt
import seaborn as sns

import scipy.stats as stats


# In[85]:


from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# In[3]:


df = pd.read_csv('100_Sales.csv').drop(columns=['Unnamed: 9','Unnamed: 10'])


# In[4]:


df.head()


# In[5]:


#Data Analysis
days = df['Ship_Date'].str.split('/').str.get(0).values
months = df['Ship_Date'].str.split('/').str.get(1).values
years = df['Ship_Date'].str.split('/').str.get(2).values


# In[6]:


date_series = years +'/' + months + '/'+ days


# In[7]:


df['Ship_Date'] = pd.to_datetime(date_series)


# In[8]:


df.info()


# In[9]:


df['Region'] = df['Region'].astype('category')
df['Item_Type'] = df['Item_Type'].astype('category')
df['Sales_Channel'] = df['Sales_Channel'].astype('category')
df['Order_Priority'] = df['Order_Priority'].astype('category')


# In[10]:


df.info()


# In[11]:


df.head()


# In[12]:


#Understanding and creating new variables
df['Expense'] = df['Total_Revenue'] -df['Total_Profit']


# In[13]:


df['Profit_Margin'] = (df['Total_Profit'] / df['Total_Revenue'] ) * 100


# In[14]:


df.head()


# In[15]:


df['Rank'] = df['Profit_Margin'].rank(ascending=False).astype('int')


# In[16]:


#Which Region earns the highest Profit Margin? *and it's associated country?
df.sort_values(by='Profit_Margin', ascending=False).head(1)


# In[17]:


#Which Region earns the highest Profit? *and it's associated country?
regions = df.groupby(by='Region')


# In[18]:


df_highest_profit_regions = pd.DataFrame(columns=df.columns)


# In[19]:


for reg, data in regions:
        highest_profit = data.nlargest(1, 'Total_Profit')
        df_highest_profit_regions = pd.concat([df_highest_profit_regions, highest_profit])


# In[20]:


df_highest_profit_regions.sort_values(by='Total_Profit', ascending=False)


# In[21]:


fig, ax = plt.subplots(figsize=(10,7))

tmp_df = df_highest_profit_regions.copy()

tmp_df = tmp_df.sort_values(by='Total_Profit', ascending=False)

sns.barplot(x = tmp_df['Total_Profit'], y=tmp_df['Region'], orient='h', data=tmp_df,\
           order=['Middle East and North Africa', 'Australia and Oceania', 'Europe', 'Central America and the Caribbean', 'Asia', 'Sub_Saharan Africa', 'North America'],
            capsize=0.2, ax=ax)

lbs = ['Middle East and North Africa: 1719922.04 \n Country: Pakistan', 
      'Australia and Oceania: 1678540.98 \n Country: Samoa',
      'Europe: 1541705.29 \n Country: Iceland',
      'Central America and the Caribbean: 1487261.02 \n Country: Honduras',
      'Asia: 1367272.50 \n Country: Myanmar',
      'Sub_Saharan Africa: 1254472.05 \n Country: Djibouti',
      'North America: 1152486.42 \n Country: Mexico']
ax.bar_label(ax.containers[-1], labels=lbs,label_type='center')

plt.title('Region with their Profits')
plt.xlabel('Regions')
plt.ylabel('Total Profit')
plt.show()


# In[22]:


#Which Region earns the highest Profit Margin?
df_highest_pmargin_region = pd.DataFrame(columns=df.columns)


# In[23]:


for reg, data in regions:
    highest_margin = data.nlargest(1, 'Profit_Margin')
    df_highest_pmargin_region = pd.concat([df_highest_pmargin_region, highest_margin])


# In[24]:


df_highest_pmargin_region.sort_values(by='Profit_Margin', ascending=False)


# In[25]:


fig, ax = plt.subplots(figsize=(10,6))

tmp_df = df_highest_profit_regions.copy()
tmp_df = tmp_df.sort_values(by='Profit_Margin', ascending=False)
plt.stem(tmp_df['Profit_Margin'],markerfmt='D')
my_range=range(1,len(tmp_df.index)+1)
plt.xticks( my_range, tmp_df['Region'], rotation=45)

plt.show()


# In[26]:


get_ipython().system('pip install squarify')


# In[27]:


regions.agg({'Country':'count',
             'Unit_Cost': 'sum',
             'Total_Revenue': 'sum',
            'Total_Profit': 'sum',
            'Expense': 'sum'})


# In[28]:


tmp_df=regions.agg({'Country':'count',
             'Unit_Cost': 'sum',
             'Total_Revenue': 'sum',
            'Total_Profit': 'sum',
            'Expense': 'sum'})


# In[29]:


plt.figure(figsize=(6,6))
tmp_df['Country'].plot.pie(autopct = "%1.0f%%", colors = sns.color_palette('copper'), shadow = True,
                          explode=(0, 0, 0, 0, 0, 0, 0.1))

plt.title('Proportion of countries per Region')
plt.axis('equal')
plt.show()


# In[30]:


import squarify


# In[31]:


plt.figure(figsize=(15,8))
revs = tmp_df['Total_Revenue'].values
labels = ['Asia: 21347091.02',
 'Australia and Oceania:\n 14094265.13',
 'Central America and the Caribbean:\n 9170385.49',
 'Europe: 33368932.11',
 'Middle East and North Africa:\n 14052706.58',
 'North America:\n 5643356.55',
 'Sub_Saharan Africa: 39672031.43']
squarify.plot(revs,label=labels, color= sns.color_palette('copper'), alpha=0.7)
plt.show()


# In[32]:


plt.figure(figsize=(15,8))
revs = tmp_df['Total_Profit'].values
labels = ['Asia: 6113845.87',
 'Australia and Oceania: 4722160.03',
 'Central America and the Caribbean:\n 2846907.85',
 'Europe: 11082938.63',
 'Middle East and North Africa:\n 5761191.859999999',
 'North America: 1457942.76',
 'Sub_Saharan Africa: 12183211.4']
squarify.plot(revs,label=labels, color= sns.color_palette('copper'), alpha=0.7)
plt.show()


# In[33]:


plt.figure(figsize=(15,8))
revs = tmp_df['Expense'].values
labels = ['Asia: 15233245.15',
 'Australia and Oceania: 9372105.1',
 'Central America and the Caribbean:\n 6323477.6400000015',
 'Europe: 22285993.479999997',
 'Middle East and North Africa:\n 8291514.72',
 'North America: 4185413.79',
 'Sub_Saharan Africa: 27488820.03']
squarify.plot(revs,label=labels, color= sns.color_palette('copper'), alpha=0.7)
plt.show()


# # Region wise profit margin over the years

# In[34]:


for k, d in regions:
    t_df = regions.get_group(k)
    t_df.set_index('Ship_Date').plot(y=['Profit_Margin'])
    plt.title('Profit Margin of {} over the years'.format(k))
    plt.show()


# ## which Item type has the highest dealears?

# In[35]:


items_group = df.groupby(by='Item_Type')


# In[36]:


items_group.agg({'Country': 'count',
                'Unit_Cost': 'sum',
                'Total_Revenue': 'sum',
                'Total_Profit': 'sum',
                'Expense': 'sum'})


# In[37]:


tmp_df = items_group.agg({'Country': 'count',
                'Unit_Cost': 'sum',
                'Total_Revenue': 'sum',
                'Total_Profit': 'sum',
                'Expense': 'sum'})


# In[38]:


plt.figure(figsize=(10,6))

tmp_df['Country'].plot.pie(autopct = "%1.0f%%", colors = sns.color_palette('copper'), shadow = True,
                          explode=(0, 0, 0, 0.1, 0.1, 0, 0, 0, 0, 0, 0, 0))

plt.title('No.Coutries dealing into each Item type')
plt.axis('equal')
plt.show()


# ## Which Item Type has the highest Total Revenue?

# In[39]:


def highlight_cols(x): 
    df = x.copy()
    df.loc[:, 'Total_Revenue'] = 'background-color: green'
    df[['Country', 'Unit_Cost', 'Total_Profit','Expense']] = 'background-color: grey'
    return df 


# In[40]:


display(tmp_df.style.apply(highlight_cols, axis = None))


# In[41]:


pip upgrade --pandas


# In[42]:


target_column = 'Total_Profit' 
X = df.drop(target_column, axis=1)  
y = df[target_column]  


# In[43]:


X = pd.get_dummies(X, drop_first=True)


# In[44]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[47]:


print("X_train shape:", X_train.shape)
print("y_train shape:", y_train.shape)


# In[49]:


print("NaN values in X_train:", X_train.isnull().sum().sum())
print("NaN values in y_train:", y_train.isnull().sum())


# In[63]:


X_train.fillna(0, inplace=True)  
y_train.fillna(0, inplace=True)


# In[64]:


print(X_train.dtypes)


# In[96]:


print(y_train.dtypes)


# In[71]:


if 'date_column' in df.columns:  
    df['date_column'] = pd.to_datetime(df['date_column'])
    df['year'] = df['date_column'].dt.year
    df['month'] = df['date_column'].dt.month
    df['day'] = df['date_column'].dt.day
    df.drop('date_column', axis=1, inplace=True)


# In[73]:


from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score


# In[74]:


dt_model = DecisionTreeClassifier(random_state=42)


# In[76]:


import sklearn
print(sklearn.__version__)


# In[88]:


df.dtypes


# In[89]:


datetime_columns = df.select_dtypes(include=['datetime64']).columns
print(f"Datetime columns: {datetime_columns}")


# In[86]:


dt_model = DecisionTreeClassifier(random_state=42)


# In[98]:


dt_model.fit(X_train,y_train)


# In[99]:


rf_model = RandomForestClassifier(random_state=42)


# In[100]:


rf_model.fit(X_train, y_train)


# In[ ]:




